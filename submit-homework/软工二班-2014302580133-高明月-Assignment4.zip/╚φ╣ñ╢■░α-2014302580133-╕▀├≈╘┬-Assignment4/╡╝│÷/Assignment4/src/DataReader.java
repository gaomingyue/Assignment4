import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;

import java.sql.SQLException;
public class DataReader {
	//��ȡ�����ݿ������������
	Connection conn = null;
	
	public String[] information = new String[26];
	//@SuppressWarnings("null")
	public void getInformation(){
		
	try{
		
		 Class.forName("com.mysql.jdbc.Driver"); // ��̬����mysql����
		// System.out.println("�ɹ�����MySQL��������");
		 conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456"); 	
		 //jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456
	

			String sql="select * from professor_info";
			 Statement stmt = conn.createStatement();
			  ResultSet rs=stmt.executeQuery(sql);
			  int i=0;
			 //String[] information = null;
			  while (rs.next()) { //ѭ����������
				  
	                String name = rs.getString("name");
	                String educationBackground = rs.getString("educationBackground");
	                String researchInterests = rs.getString("researchInterests");
	                String email = rs.getString("email");
	                String phone = rs.getString("phone");
	                information[i]="Name:" + name +"\r\n"+ "EducationBackground:" + educationBackground+"\r\n"+ "ResearchInterests:" + researchInterests+"Email:" + email+"\r\n"+ "Phone:" + phone+"\r\n";
	                i++;
	                //System.out.print("\r\n\r\n");
	               // System.out.print("name:" + name +"\r\n"+ "educationBackground:" + educationBackground+"\r\n"+ "researchInterests:" + researchInterests+"\r\n"+ "email:" + email+"\r\n"+ "phone:" + phone+"\r\n");
	            }
		}	catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}    
		catch(Exception e){
		     System.out.println("���������׳��쳣Ϊ��"+e.getMessage());
		    }
	}
}
