
import javax.swing.JFrame;
//import javax.swing.JPanel;
//import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;

import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.SystemColor;

public class GUI extends JFrame {
	public GUI() {
		getContentPane().setBackground(SystemColor.control);
		
		
		setTitle("Professor Search");
		getContentPane().setLayout(null);
		setBounds(100,100,440,310);
		
		JTextField textField_1 = new JTextField();
		textField_1.setBounds(10, 22, 250, 21);
		getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(10, 65, 400, 187);
		getContentPane().add(textArea);
		
		JButton btnNewButton = new JButton("Search");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String text=textField_1.getText();
				Macher macher=new Macher(text);
				macher.keywords();
				String st ="";
				for(int i=0;i<26;i++){
					if(macher.TF[i]>0){
						//System.out.print(macher.info[i]);
						//System.out.print(TF[i]);
						st=st+macher.info[i]+"\r\n";
						//textArea.append(macher.info[i]);
					}
				}
				textArea.setText(st);
			}
		});
		btnNewButton.setBounds(303, 21, 100, 23);
		getContentPane().add(btnNewButton);
		
			
	
		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setBounds(15, 75, 400, 180);
		getContentPane().add(scrollPane);
	
		
	}


	/**
	 * 
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI frame = new GUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
}
