
public class Macher {
	private String input;
	//private String information;
public Macher(String input){
	this.input=input;
	
}
public String[] info=new String[26];
int[] TF=new int[26];
public void keywords(){
	DataReader dr=new DataReader();
	dr.getInformation();
	//String[] strarray1=dr.information[0].split(" |,");
	
	

	for(int i=0;i<26;i++){
	String[] strarray=dr.information[i].split(" |,|:");
	//�ɷָ���Գɹ�
	int selected=0;
	String[] strarray2=input.split(" |,");
	for(int a=0;a<strarray2.length;a++){
	for(int j=0;j<strarray.length;j++){
		 boolean retval = strarray[j].contains( strarray2[a]);
			if(retval){
			selected++;
				//System.out.print(strarray[j]+"/r/n");
			}
	
		}
	}
	//int all=strarray.length;	
	
	TF[i]=selected;
	}
	
	//����һ��TFֵ
	//for(int r=0;r<26;r++){
		//System.out.print(TF[r]);
	//}
	//����TFֵ������information��������
	//ð������
	for(int i=0;i<26;i++){
		for(int j=25;j>i;j--){
			if(TF[j]>TF[j-1]){
				String replace=dr.information[j];
				dr.information[j]=dr.information[j-1];
				dr.information[j-1]=replace;
				
				int  replace1=TF[j];
				TF[j]=TF[j-1];
				TF[j-1]=replace1;
			}
		}
	}
	
	
	for(int i=0;i<26;i++){
		info[i]=dr.information[i];
	}
	

}
}
